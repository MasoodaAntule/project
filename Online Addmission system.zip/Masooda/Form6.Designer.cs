﻿namespace Masooda
{
    partial class Form6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label pRNLabel;
            System.Windows.Forms.Label student_NameLabel;
            System.Windows.Forms.Label mobile_No_Label;
            System.Windows.Forms.Label classLabel;
            System.Windows.Forms.Label addressLabel;
            System.Windows.Forms.Label email_IDLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form6));
            this.detailDataSet1 = new Masooda.DetailDataSet1();
            this.detailBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.detailTableAdapter = new Masooda.DetailDataSet1TableAdapters.DetailTableAdapter();
            this.tableAdapterManager = new Masooda.DetailDataSet1TableAdapters.TableAdapterManager();
            this.detailBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.detailBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.pRNTextBox = new System.Windows.Forms.TextBox();
            this.student_NameTextBox = new System.Windows.Forms.TextBox();
            this.mobile_No_TextBox = new System.Windows.Forms.TextBox();
            this.classTextBox = new System.Windows.Forms.TextBox();
            this.addressTextBox = new System.Windows.Forms.TextBox();
            this.email_IDTextBox = new System.Windows.Forms.TextBox();
            this.detailDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.errorProvider4 = new System.Windows.Forms.ErrorProvider(this.components);
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            pRNLabel = new System.Windows.Forms.Label();
            student_NameLabel = new System.Windows.Forms.Label();
            mobile_No_Label = new System.Windows.Forms.Label();
            classLabel = new System.Windows.Forms.Label();
            addressLabel = new System.Windows.Forms.Label();
            email_IDLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.detailDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.detailBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.detailBindingNavigator)).BeginInit();
            this.detailBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.detailDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider4)).BeginInit();
            this.SuspendLayout();
            // 
            // pRNLabel
            // 
            pRNLabel.AutoSize = true;
            pRNLabel.BackColor = System.Drawing.Color.White;
            pRNLabel.Font = new System.Drawing.Font("Times New Roman", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            pRNLabel.ForeColor = System.Drawing.Color.Indigo;
            pRNLabel.Location = new System.Drawing.Point(389, 211);
            pRNLabel.Name = "pRNLabel";
            pRNLabel.Size = new System.Drawing.Size(94, 38);
            pRNLabel.TabIndex = 2;
            pRNLabel.Text = "PRN:";
            pRNLabel.Click += new System.EventHandler(this.pRNLabel_Click);
            // 
            // student_NameLabel
            // 
            student_NameLabel.AutoSize = true;
            student_NameLabel.BackColor = System.Drawing.Color.White;
            student_NameLabel.Font = new System.Drawing.Font("Times New Roman", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            student_NameLabel.ForeColor = System.Drawing.Color.Indigo;
            student_NameLabel.Location = new System.Drawing.Point(256, 264);
            student_NameLabel.Name = "student_NameLabel";
            student_NameLabel.Size = new System.Drawing.Size(223, 38);
            student_NameLabel.TabIndex = 4;
            student_NameLabel.Text = "Student Name:";
            student_NameLabel.Click += new System.EventHandler(this.student_NameLabel_Click);
            // 
            // mobile_No_Label
            // 
            mobile_No_Label.AutoSize = true;
            mobile_No_Label.BackColor = System.Drawing.Color.White;
            mobile_No_Label.Font = new System.Drawing.Font("Times New Roman", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            mobile_No_Label.ForeColor = System.Drawing.Color.Indigo;
            mobile_No_Label.Location = new System.Drawing.Point(301, 328);
            mobile_No_Label.Name = "mobile_No_Label";
            mobile_No_Label.Size = new System.Drawing.Size(181, 38);
            mobile_No_Label.TabIndex = 6;
            mobile_No_Label.Text = "Mobile No :";
            mobile_No_Label.Click += new System.EventHandler(this.mobile_No_Label_Click);
            // 
            // classLabel
            // 
            classLabel.AutoSize = true;
            classLabel.BackColor = System.Drawing.Color.White;
            classLabel.Font = new System.Drawing.Font("Times New Roman", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            classLabel.ForeColor = System.Drawing.Color.Indigo;
            classLabel.Location = new System.Drawing.Point(887, 203);
            classLabel.Name = "classLabel";
            classLabel.Size = new System.Drawing.Size(102, 38);
            classLabel.TabIndex = 8;
            classLabel.Text = "Class:";
            classLabel.Click += new System.EventHandler(this.classLabel_Click);
            // 
            // addressLabel
            // 
            addressLabel.AutoSize = true;
            addressLabel.BackColor = System.Drawing.Color.White;
            addressLabel.Font = new System.Drawing.Font("Times New Roman", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            addressLabel.ForeColor = System.Drawing.Color.Indigo;
            addressLabel.Location = new System.Drawing.Point(854, 264);
            addressLabel.Name = "addressLabel";
            addressLabel.Size = new System.Drawing.Size(138, 38);
            addressLabel.TabIndex = 10;
            addressLabel.Text = "Address:";
            addressLabel.Click += new System.EventHandler(this.addressLabel_Click);
            // 
            // email_IDLabel
            // 
            email_IDLabel.AutoSize = true;
            email_IDLabel.BackColor = System.Drawing.Color.White;
            email_IDLabel.Font = new System.Drawing.Font("Times New Roman", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            email_IDLabel.ForeColor = System.Drawing.Color.Indigo;
            email_IDLabel.Location = new System.Drawing.Point(851, 326);
            email_IDLabel.Name = "email_IDLabel";
            email_IDLabel.Size = new System.Drawing.Size(157, 38);
            email_IDLabel.TabIndex = 12;
            email_IDLabel.Text = "Email ID:";
            email_IDLabel.Click += new System.EventHandler(this.email_IDLabel_Click);
            // 
            // detailDataSet1
            // 
            this.detailDataSet1.DataSetName = "DetailDataSet1";
            this.detailDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // detailBindingSource
            // 
            this.detailBindingSource.DataMember = "Detail";
            this.detailBindingSource.DataSource = this.detailDataSet1;
            // 
            // detailTableAdapter
            // 
            this.detailTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.DetailTableAdapter = this.detailTableAdapter;
            this.tableAdapterManager.UpdateOrder = Masooda.DetailDataSet1TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // detailBindingNavigator
            // 
            this.detailBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.detailBindingNavigator.BindingSource = this.detailBindingSource;
            this.detailBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.detailBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.detailBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.detailBindingNavigatorSaveItem});
            this.detailBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.detailBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.detailBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.detailBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.detailBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.detailBindingNavigator.Name = "detailBindingNavigator";
            this.detailBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.detailBindingNavigator.Size = new System.Drawing.Size(1602, 27);
            this.detailBindingNavigator.TabIndex = 0;
            this.detailBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 24);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(45, 24);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 24);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 24);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 24);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 27);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 24);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 24);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 27);
            // 
            // detailBindingNavigatorSaveItem
            // 
            this.detailBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.detailBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("detailBindingNavigatorSaveItem.Image")));
            this.detailBindingNavigatorSaveItem.Name = "detailBindingNavigatorSaveItem";
            this.detailBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 24);
            this.detailBindingNavigatorSaveItem.Text = "Save Data";
            this.detailBindingNavigatorSaveItem.Click += new System.EventHandler(this.detailBindingNavigatorSaveItem_Click);
            // 
            // pRNTextBox
            // 
            this.pRNTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.detailBindingSource, "PRN", true));
            this.pRNTextBox.Location = new System.Drawing.Point(536, 211);
            this.pRNTextBox.Multiline = true;
            this.pRNTextBox.Name = "pRNTextBox";
            this.pRNTextBox.Size = new System.Drawing.Size(134, 35);
            this.pRNTextBox.TabIndex = 3;
            this.pRNTextBox.TextChanged += new System.EventHandler(this.pRNTextBox_TextChanged);
            this.pRNTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.pRNTextBox_KeyPress);
            this.pRNTextBox.Validating += new System.ComponentModel.CancelEventHandler(this.pRNTextBox_Validating);
            // 
            // student_NameTextBox
            // 
            this.student_NameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.detailBindingSource, "Student Name", true));
            this.student_NameTextBox.Location = new System.Drawing.Point(536, 272);
            this.student_NameTextBox.Multiline = true;
            this.student_NameTextBox.Name = "student_NameTextBox";
            this.student_NameTextBox.Size = new System.Drawing.Size(247, 35);
            this.student_NameTextBox.TabIndex = 5;
            this.student_NameTextBox.TextChanged += new System.EventHandler(this.student_NameTextBox_TextChanged);
            this.student_NameTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.student_NameTextBox_KeyPress);
            this.student_NameTextBox.Validating += new System.ComponentModel.CancelEventHandler(this.student_NameTextBox_Validating);
            // 
            // mobile_No_TextBox
            // 
            this.mobile_No_TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.detailBindingSource, "Mobile No_", true));
            this.mobile_No_TextBox.Location = new System.Drawing.Point(536, 330);
            this.mobile_No_TextBox.MaxLength = 10;
            this.mobile_No_TextBox.Multiline = true;
            this.mobile_No_TextBox.Name = "mobile_No_TextBox";
            this.mobile_No_TextBox.Size = new System.Drawing.Size(247, 35);
            this.mobile_No_TextBox.TabIndex = 7;
            this.mobile_No_TextBox.TextChanged += new System.EventHandler(this.mobile_No_TextBox_TextChanged);
            this.mobile_No_TextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.mobile_No_TextBox_KeyPress);
            this.mobile_No_TextBox.Validating += new System.ComponentModel.CancelEventHandler(this.mobile_No_TextBox_Validating);
            // 
            // classTextBox
            // 
            this.classTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.detailBindingSource, "Class", true));
            this.classTextBox.Location = new System.Drawing.Point(1037, 211);
            this.classTextBox.Multiline = true;
            this.classTextBox.Name = "classTextBox";
            this.classTextBox.Size = new System.Drawing.Size(134, 35);
            this.classTextBox.TabIndex = 9;
            this.classTextBox.TextChanged += new System.EventHandler(this.classTextBox_TextChanged);
            this.classTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.classTextBox_KeyPress);
            this.classTextBox.Validating += new System.ComponentModel.CancelEventHandler(this.classTextBox_Validating);
            // 
            // addressTextBox
            // 
            this.addressTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.detailBindingSource, "Address", true));
            this.addressTextBox.Location = new System.Drawing.Point(1037, 268);
            this.addressTextBox.Multiline = true;
            this.addressTextBox.Name = "addressTextBox";
            this.addressTextBox.Size = new System.Drawing.Size(247, 35);
            this.addressTextBox.TabIndex = 11;
            this.addressTextBox.TextChanged += new System.EventHandler(this.addressTextBox_TextChanged);
            this.addressTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.addressTextBox_KeyPress);
            this.addressTextBox.Validating += new System.ComponentModel.CancelEventHandler(this.addressTextBox_Validating);
            // 
            // email_IDTextBox
            // 
            this.email_IDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.detailBindingSource, "Email ID", true));
            this.email_IDTextBox.Location = new System.Drawing.Point(1037, 330);
            this.email_IDTextBox.Multiline = true;
            this.email_IDTextBox.Name = "email_IDTextBox";
            this.email_IDTextBox.Size = new System.Drawing.Size(247, 35);
            this.email_IDTextBox.TabIndex = 13;
            this.email_IDTextBox.TextChanged += new System.EventHandler(this.email_IDTextBox_TextChanged);
            this.email_IDTextBox.Leave += new System.EventHandler(this.email_IDTextBox_Leave);
            this.email_IDTextBox.Validating += new System.ComponentModel.CancelEventHandler(this.email_IDTextBox_Validating);
            // 
            // detailDataGridView
            // 
            this.detailDataGridView.AutoGenerateColumns = false;
            this.detailDataGridView.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.detailDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.detailDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6});
            this.detailDataGridView.DataSource = this.detailBindingSource;
            this.detailDataGridView.Location = new System.Drawing.Point(279, 391);
            this.detailDataGridView.Name = "detailDataGridView";
            this.detailDataGridView.RowTemplate.Height = 24;
            this.detailDataGridView.Size = new System.Drawing.Size(985, 312);
            this.detailDataGridView.TabIndex = 13;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "PRN";
            this.dataGridViewTextBoxColumn1.HeaderText = "PRN";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Student Name";
            this.dataGridViewTextBoxColumn2.HeaderText = "Student Name";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Mobile No_";
            this.dataGridViewTextBoxColumn3.HeaderText = "Mobile No_";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Class";
            this.dataGridViewTextBoxColumn4.HeaderText = "Class";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Address";
            this.dataGridViewTextBoxColumn5.HeaderText = "Address";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Email ID";
            this.dataGridViewTextBoxColumn6.HeaderText = "Email ID";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 25.8F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic)
                            | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(683, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(289, 49);
            this.label1.TabIndex = 14;
            this.label1.Text = "Student Detail ";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // errorProvider4
            // 
            this.errorProvider4.ContainerControl = this;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Transparent;
            this.button4.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.Indigo;
            this.button4.Image = global::Masooda.Properties.Resources.icons8_close_window_64;
            this.button4.Location = new System.Drawing.Point(1785, 41);
            this.button4.Margin = new System.Windows.Forms.Padding(4);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(39, 32);
            this.button4.TabIndex = 18;
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Transparent;
            this.button3.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.Indigo;
            this.button3.Image = global::Masooda.Properties.Resources.icons8_maximize_window_64;
            this.button3.Location = new System.Drawing.Point(1727, 41);
            this.button3.Margin = new System.Windows.Forms.Padding(4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(39, 32);
            this.button3.TabIndex = 17;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Transparent;
            this.button2.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.Indigo;
            this.button2.Image = global::Masooda.Properties.Resources.icons8_minimize_window_64;
            this.button2.Location = new System.Drawing.Point(1663, 41);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(39, 32);
            this.button2.TabIndex = 16;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleTurquoise;
            this.BackgroundImage = global::Masooda.Properties.Resources.A;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1602, 655);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.detailDataGridView);
            this.Controls.Add(pRNLabel);
            this.Controls.Add(this.pRNTextBox);
            this.Controls.Add(student_NameLabel);
            this.Controls.Add(this.student_NameTextBox);
            this.Controls.Add(mobile_No_Label);
            this.Controls.Add(this.mobile_No_TextBox);
            this.Controls.Add(classLabel);
            this.Controls.Add(this.classTextBox);
            this.Controls.Add(addressLabel);
            this.Controls.Add(this.addressTextBox);
            this.Controls.Add(email_IDLabel);
            this.Controls.Add(this.email_IDTextBox);
            this.Controls.Add(this.detailBindingNavigator);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form6";
            this.Text = "Form6";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form6_Load);
            ((System.ComponentModel.ISupportInitialize)(this.detailDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.detailBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.detailBindingNavigator)).EndInit();
            this.detailBindingNavigator.ResumeLayout(false);
            this.detailBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.detailDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DetailDataSet1 detailDataSet1;
        private System.Windows.Forms.BindingSource detailBindingSource;
        private DetailDataSet1TableAdapters.DetailTableAdapter detailTableAdapter;
        private DetailDataSet1TableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator detailBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton detailBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox pRNTextBox;
        private System.Windows.Forms.TextBox student_NameTextBox;
        private System.Windows.Forms.TextBox mobile_No_TextBox;
        private System.Windows.Forms.TextBox classTextBox;
        private System.Windows.Forms.TextBox addressTextBox;
        private System.Windows.Forms.TextBox email_IDTextBox;
        private System.Windows.Forms.DataGridView detailDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ErrorProvider errorProvider4;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
    }
}