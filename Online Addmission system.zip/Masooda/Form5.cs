﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace Masooda
{
    public partial class Form5 : Form
    {
        public static string SetValueFortextBox1 = "";
        public static string SetValueFortextBox2 = "";
        public static string SetValueFortextBox3 = "";
        public static string SetValueFortextBox4 = "";
        public static string SetValueFortextBox5 = "";
        public static string SetValueFortextBox6 = "";
        public Form5()
        {
            InitializeComponent();
        }
        

        private void subjectBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.staffBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.staffDataSet1);

        }

        private void staffBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.staffBindingSource.EndEdit();

            SetValueFortextBox1 = staff_IDTextBox.Text;
            SetValueFortextBox2 = full_NameTextBox.Text;
            SetValueFortextBox3 = mobile_TextBox.Text;
            SetValueFortextBox4 = email_IDTextBox.Text;
            SetValueFortextBox5 = genderTextBox.Text;
            SetValueFortextBox6 = addressTextBox.Text;
            string staff_id, full_name, gender, mobile_no, emailid, address ;
            staff_id = staff_IDTextBox.Text;
            full_name = full_NameTextBox.Text;
            mobile_no = mobile_TextBox.Text;
            emailid = email_IDTextBox.Text;
            gender = genderTextBox.Text;
            address = addressTextBox.Text;

            MessageBox.Show("Staff ID:" + staff_id + "\nFull Name:" + full_name + "\nMobile No:" + gender + "\nMail Id:" + emailid +  "\nGender:" + gender + "\naddress:" + address );
            staff_IDTextBox.Clear();
            full_NameTextBox.Clear();
            mobile_TextBox.Clear();
            email_IDTextBox.Clear();
            genderTextBox.Clear();
            addressTextBox.Clear();
            staff_IDTextBox.Focus();

        }

        private void Form5_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'staffDataSet1.Staff' table. You can move, or remove it, as needed.
            this.staffTableAdapter.Fill(this.staffDataSet1.Staff);

        }

        private void staff_IDLabel_Click(object sender, EventArgs e)
        {

        }

        private void staff_IDTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void full_NameLabel_Click(object sender, EventArgs e)
        {

        }

        private void full_NameTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void genderLabel_Click(object sender, EventArgs e)
        {

        }

        private void genderTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void mobile_Label_Click(object sender, EventArgs e)
        {

        }

        private void mobile_TextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void email_IDLabel_Click(object sender, EventArgs e)
        {

        }

        private void email_IDTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void addressLabel_Click(object sender, EventArgs e)
        {

        }

        private void addressTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void staff_IDTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != 8))
            {
                MessageBox.Show("Enter Numbers Only");
                e.Handled = true;
            }
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void full_NameTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) == false && Convert.ToInt32(e.KeyChar) != 8)
                if (e.KeyChar != ' ')
                {
                    MessageBox.Show("Enter characters Only");
                    e.Handled = true;
                }
        }

        private void genderTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) == false && Convert.ToInt32(e.KeyChar) != 8)
                if (e.KeyChar != ' ')
                {
                    MessageBox.Show("Enter characters Only");
                    e.Handled = true;
                }
        }

        private void mobile_TextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);    
        }

        private void email_IDTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
        }
        private void addressTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) == false && Convert.ToInt32(e.KeyChar) != 8)
                if (e.KeyChar != ' ')
                {
                    MessageBox.Show("Enter characters Only");
                    e.Handled = true;
                }
        }

        private void email_IDTextBox_Layout(object sender, LayoutEventArgs e)
        {

        }

        private void email_IDTextBox_Leave(object sender, EventArgs e)
        {
            string pattern = "^([0-9a-zA-Z]([-\\.\\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\\w]*[0-9a-zA-Z]\\.)+[a-zA-Z]{2,9})$";
            if (Regex.IsMatch(email_IDTextBox.Text, pattern))
            {
                errorProvider3.Clear();
            }
            else
            {
                errorProvider3.SetError(this.email_IDTextBox, "Please Enter valide Email Address");
            }
        }

        private void staff_IDTextBox_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(staff_IDTextBox.Text.Trim()))
            {
                errorProvider3.SetError(staff_IDTextBox, "Please Enter Your ID.");
            }
            else
            {
                errorProvider3.SetError(staff_IDTextBox, string.Empty);
            }
           
        }

        private void full_NameTextBox_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(full_NameTextBox.Text.Trim()))
            {
                errorProvider3.SetError(full_NameTextBox, "Please Enter Your Name.");
            }
            else
            {
                errorProvider3.SetError(full_NameTextBox, string.Empty);
            }
           
        }

        private void genderTextBox_Validating(object sender, EventArgs e)
        {
          
        }

        private void genderTextBox_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(genderTextBox.Text.Trim()))
            {
                errorProvider3.SetError(genderTextBox, "Please Enter Your Gender.");
            }
            else
            {
                errorProvider3.SetError(genderTextBox, string.Empty);
            }
        }

        private void mobile_TextBox_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(mobile_TextBox.Text.Trim()))
            {
                errorProvider3.SetError(mobile_TextBox, "Please Enter Your mobile No.");
            }
            else
            {
                errorProvider3.SetError(mobile_TextBox, string.Empty);
            }
        }

        private void addressTextBox_Validated(object sender, EventArgs e)
        {

        }

        private void addressTextBox_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(addressTextBox.Text.Trim()))
            {
                errorProvider3.SetError(addressTextBox, "Please Enter Your Address.");
            }
            else
            {
                errorProvider3.SetError(addressTextBox, string.Empty);
            }
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
                   
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
