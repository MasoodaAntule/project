﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Masooda
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void subjectBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.subjectBindingSource.EndEdit();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'subjectsDataSet2.Subject' table. You can move, or remove it, as needed.
            this.subjectTableAdapter1.Fill(this.subjectsDataSet2.Subject);
            // TODO: This line of code loads data into the 'subjectsDataSet1.Subject' table. You can move, or remove it, as needed.
            this.subjectTableAdapter.Fill(this.subjectsDataSet1.Subject);

        }

        private void subjectLabel_Click(object sender, EventArgs e)
        {

        }

        private void classTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void classTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) == false && Convert.ToInt32(e.KeyChar) != 8)
                if (e.KeyChar != ' ')
            {
                MessageBox.Show("Enter characters Only");
                e.Handled = true;
            }
        }

        private void subjectTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) == false && Convert.ToInt32(e.KeyChar) != 8)
                if (e.KeyChar != ' ')
            {
                MessageBox.Show("Enter characters Only");
                e.Handled = true;
            }
        }

        private void subject_TeacherTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) == false && Convert.ToInt32(e.KeyChar) != 8)
                if (e.KeyChar != ' ')
                {
                    MessageBox.Show("Enter characters Only");
                    e.Handled = true;
                }
        }

        private void classTextBox_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(classTextBox.Text.Trim()))
            {
                errorProvider2.SetError(classTextBox, "Please Enter The Class.");
            }
            else
            {
                errorProvider2.SetError(classTextBox, string.Empty);
            }
        }

        private void subjectTextBox_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(subjectTextBox.Text.Trim()))
            {
                errorProvider2.SetError(subjectTextBox, "Please Enter The Subject.");
            }
            else
            {
                errorProvider2.SetError(subjectTextBox, string.Empty);
            }
        }

        private void subject_TeacherTextBox_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(subject_TeacherTextBox.Text.Trim()))
            {
                errorProvider2.SetError(subject_TeacherTextBox, "Please Enter The Subject Teacher.");
            }
            else
            {
                errorProvider2.SetError(subject_TeacherTextBox, string.Empty);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }
    }
}
