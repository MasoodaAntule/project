﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Masooda
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void academicSetupToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void addNewClassToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new Form3().Show();
        }

        private void addNewSubjectToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new Form4().Show();
        }

        private void viewStaffListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new Form5().Show();
        }

        private void studentDetailToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new Form6().Show();
        }

        private void studentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void admissionToolStripMenuItem1_Click(object sender, EventArgs e)
        {
          
        }

        private void staffReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
          
        }

        private void loginToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new Form8().Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button3_Click(object sender, EventArgs e)
        {
             this.Close();
        }

        private void reprtToolStripMenuItem_Click(object sender, EventArgs e)
        {
       
        }
    }
}
