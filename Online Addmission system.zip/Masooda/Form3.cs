﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Masooda
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void feesBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.feesBindingSource.EndEdit();

        }

        private void Form3_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'feesDataSet1.Fees' table. You can move, or remove it, as needed.
            this.feesTableAdapter.Fill(this.feesDataSet1.Fees);

        }

        private void classTextBox_TextChanged(object sender, EventArgs e)
        {
        }

        private void feesTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void classTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            {
                if (!char.IsLetter(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar) && e.KeyChar != '\b')
                    if (e.KeyChar != ' ')
                    {
                        MessageBox.Show("Enter Characters Only");
                        e.Handled = true;
                    }
            }
        }

        private void feesTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != 8))
            {
                MessageBox.Show("Enter Numbers Only");
                e.Handled = true;
            }
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {  
                e.Handled = true;
            }
        }

        private void classTextBox_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(classTextBox.Text.Trim()))
            {
                errorProvider1.SetError(classTextBox, "Please Enter The Class.");
            }
            else
            {
                errorProvider1.SetError(classTextBox, string.Empty);
            }
        }

        private void feesTextBox_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(feesTextBox.Text.Trim()))
            {
                errorProvider1.SetError(feesTextBox, "Please Enter The Fees.");
            }
            else
            {
                errorProvider1.SetError(feesTextBox, string.Empty);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
