﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace Masooda
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void detailBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.detailBindingSource.EndEdit();
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'detailDataSet1.Detail' table. You can move, or remove it, as needed.
            this.detailTableAdapter.Fill(this.detailDataSet1.Detail);

        }

        private void pRNLabel_Click(object sender, EventArgs e)
        {

        }

        private void student_NameLabel_Click(object sender, EventArgs e)
        {
            
        }

        private void student_NameTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void pRNTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void mobile_No_Label_Click(object sender, EventArgs e)
        {

        }

        private void mobile_No_TextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void classLabel_Click(object sender, EventArgs e)
        {

        }

        private void classTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void addressLabel_Click(object sender, EventArgs e)
        {

        }

        private void addressTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void email_IDLabel_Click(object sender, EventArgs e)
        {

        }

        private void email_IDTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pRNTextBox_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(pRNTextBox.Text.Trim()))
            {
                errorProvider4.SetError(pRNTextBox, "Please Enter Your PRN number.");
            }
            else
            {
                errorProvider4.SetError(pRNTextBox, string.Empty);
            }
        }

        private void student_NameTextBox_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(student_NameTextBox.Text.Trim()))
            {
                errorProvider4.SetError(student_NameTextBox, "Please Enter Your Name.");
            }
            else
            {
                errorProvider4.SetError(student_NameTextBox, string.Empty);
            }
        }

        private void mobile_No_TextBox_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(mobile_No_TextBox.Text.Trim()))
            {
                errorProvider4.SetError(mobile_No_TextBox, "Please Enter Your Mobile No.");
            }
            else
            {
                errorProvider4.SetError(mobile_No_TextBox, string.Empty);
            }
        }

        private void classTextBox_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(classTextBox.Text.Trim()))
            {
                errorProvider4.SetError(classTextBox, "Please Enter Your Class.");
            }
            else
            {
                errorProvider4.SetError(classTextBox, string.Empty);
            }
        }

        private void addressTextBox_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(addressTextBox.Text.Trim()))
            {
                errorProvider4.SetError(addressTextBox, "Please Enter Your Address.");
            }
            else
            {
                errorProvider4.SetError(addressTextBox, string.Empty);
            }
        }

        private void email_IDTextBox_Validating(object sender, CancelEventArgs e)
        {
        }

        private void email_IDTextBox_Leave(object sender, EventArgs e)
        {

            string pattern = "^([0-9a-zA-Z]([-\\.\\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\\w]*[0-9a-zA-Z]\\.)+[a-zA-Z]{2,9})$";
            if (Regex.IsMatch(email_IDTextBox.Text, pattern))
            {
                errorProvider4.Clear();
            }
            else
            {
                errorProvider4.SetError(this.email_IDTextBox, "Please Enter valide Email Address");
            }
        }

        private void pRNTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != 8))
            {
                MessageBox.Show("Enter Numbers Only");
                e.Handled = true;
            }
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void student_NameTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) == false && Convert.ToInt32(e.KeyChar) != 8)
                if (e.KeyChar != ' ')
                {
                    MessageBox.Show("Enter characters Only");
                    e.Handled = true;
                }
        }

        private void classTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) == false && Convert.ToInt32(e.KeyChar) != 8)
                if (e.KeyChar != ' ')
                {
                    MessageBox.Show("Enter characters Only");
                    e.Handled = true;
                }
        }

        private void mobile_No_TextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);   
        }

        private void addressTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) == false && Convert.ToInt32(e.KeyChar) != 8)
                if (e.KeyChar != ' ')
                {
                    MessageBox.Show("Enter characters Only");
                    e.Handled = true;
                }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
